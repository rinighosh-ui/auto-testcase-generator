# Entry point for Auto Testcase Generator

def main():
    print('Auto Testcase Generator is running...')

if __name__ == '__main__':
    main()
