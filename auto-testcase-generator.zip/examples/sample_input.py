# Sample input file for testing

def add(a, b):
    return a + b
