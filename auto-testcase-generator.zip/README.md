# Auto Testcase Generator

Automatically generate unit test cases from source code or specifications using static analysis and AI-based heuristics.

## 🚀 Features

- Parse Python code to identify functions and expected inputs
- Generate unit tests using `unittest` or `pytest`
- Support for custom input/output formats
- CLI and GUI support (coming soon)

## 🛠️ Installation

```bash
git clone https://github.com/your-username/auto-testcase-generator.git
cd auto-testcase-generator
pip install -r requirements.txt
```

## 🧪 Usage

```bash
python main.py --input examples/sample_input.py --output test/test_main.py
```

## 📂 Folder Structure

- `main.py`: Entry point for the generator
- `test/`: Generated and manual test cases
- `examples/`: Sample input files
- `docs/`: Documentation and usage guides

## 📌 TODO

- [ ] Add support for JavaScript and Java
- [ ] Integrate with GitHub Actions
- [ ] Add GUI using Tkinter or PyQt

## 📄 License

This project is licensed under the MIT License.

---

Feel free to contribute or raise issues!
